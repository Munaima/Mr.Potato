package com.example.mrpotato;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void hatclicked(View view){
        ImageView hatpic = (ImageView) findViewById(R.id.Hatpic);
        CheckBox  hat = (CheckBox) findViewById(R.id.Hat);
        if(hat.isChecked()){
            hatpic.setVisibility(View.VISIBLE);
        }
        else{
            hatpic.setVisibility(View.INVISIBLE);
        }

    }
    public void shoeClicked(View view){
        ImageView shoepic = (ImageView) findViewById(R.id.shoepic);
        CheckBox  shoe = (CheckBox) findViewById(R.id.shoe);
        if(shoe.isChecked()){
            shoepic.setVisibility(View.VISIBLE);
        }
        else{
            shoepic.setVisibility(View.INVISIBLE);
        }

    }
    public void mouthClicked(View view){
        ImageView mouthpic = (ImageView) findViewById(R.id.mouthpic);
        CheckBox  mouth = (CheckBox) findViewById(R.id.mouth);
        if(mouth.isChecked()){
            mouthpic.setVisibility(View.VISIBLE);
        }
        else{
            mouthpic.setVisibility(View.INVISIBLE);
        }

    }
    public void moustacheClicked(View view){
        ImageView moustachepic = (ImageView) findViewById(R.id.moustachepic);
        CheckBox  moustache = (CheckBox) findViewById(R.id.moustache);
        if(moustache.isChecked()){
            moustachepic.setVisibility(View.VISIBLE);
        }
        else{
            moustachepic.setVisibility(View.INVISIBLE);
        }

    }
    public void noseClicked(View view){
        ImageView nosepic = (ImageView) findViewById(R.id.nosepic);
        CheckBox  nose = (CheckBox) findViewById(R.id.nose);
        if(nose.isChecked()){
            nosepic.setVisibility(View.VISIBLE);
        }
        else{
            nosepic.setVisibility(View.INVISIBLE);
        }

    }
    public void eyesClicked(View view){
        ImageView eyespic = (ImageView) findViewById(R.id.eyespic);
        CheckBox  eye = (CheckBox) findViewById(R.id.eyes);
        if(eye.isChecked()){
            eyespic.setVisibility(View.VISIBLE);
        }
        else{
            eyespic.setVisibility(View.INVISIBLE);
        }

    }

    public void eyebrowClicked(View view){
        ImageView eyebrowpic = (ImageView) findViewById(R.id.eyesbrowpic);
        CheckBox  eyebrow = (CheckBox) findViewById(R.id.eyebrow);
        if(eyebrow.isChecked()){
            eyebrowpic.setVisibility(View.VISIBLE);
        }
        else{
            eyebrowpic.setVisibility(View.INVISIBLE);
        }

    }

    public void glassesClicked(View view){
        ImageView glassespic = (ImageView) findViewById(R.id.glassespic);
        CheckBox  glass = (CheckBox) findViewById(R.id.glasses);
        if(glass.isChecked()){
            glassespic.setVisibility(View.VISIBLE);
        }
        else{
            glassespic.setVisibility(View.INVISIBLE);
        }

    }
}